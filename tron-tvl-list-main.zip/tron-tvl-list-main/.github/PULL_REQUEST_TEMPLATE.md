## **Please provide the following information for your Defi project.**
Please include change to the `defiProjectList.json` file in the PR.
DON'T modify any other project's contents.

##### Twitter Link:

##### List of audit links if any:

##### Homepage:

##### Logo (High resolution, preferably in .svg and .png, for application on both white and black backgrounds. Will be shown with rounded borders):

#### URL to get TVL:

##### Current TVL:

##### MarketCap link (so your TVL can appear on Coinmarketcap or Coingecko): (https://coinmarketcap.com/currencies/#TOKEN or https://www.coingecko.com/en/coins/#TOKEN)

##### Short Description:

##### Token address and ticker if any:

##### Pool addresses:

##### Category (Yield/DEX/Lending/Minting/Assets/Insurance/Options/Indexes/Staking) *Please choose only one:

##### Oracle used (WINkLink/Chainlink/Band/API3/TWAP or any other that you are using):

##### forkedFrom (Does your project originate from another project):

##### methodology (what is being counted as tvl, how is tvl being calculated):

